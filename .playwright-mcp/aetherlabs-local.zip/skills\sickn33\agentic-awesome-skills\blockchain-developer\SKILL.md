---
name: "blockchain-developer"
description: "Build production-ready Web3 applications, smart contracts, and decentralized systems. Implements DeFi protocols, NFT platforms, DAOs, and enterprise blockchain integrations."
slug: "blockchain-developer"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "b4bd5a153dd1e0a66789b6c971f731cdcf492a46"
      path: "skills/blockchain-developer"
      repo: "sickn33/agentic-awesome-skills"
      trackingRef: "main"
      url: "https://skills.sh/sickn33/agentic-awesome-skills/blockchain-developer"
key: "sickn33/agentic-awesome-skills/blockchain-developer"
---

