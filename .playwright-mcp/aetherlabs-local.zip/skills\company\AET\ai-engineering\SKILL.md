---
slug: "ai-engineering"
metadata:
  paperclip:
    slug: "ai-engineering"
    skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/ai-engineering"
  paperclipSkillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/ai-engineering"
  skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/ai-engineering"
key: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/ai-engineering"
---

---
name: ai-engineering
description: AI/ML engineering, model integration, LLM systems, and data pipelines.
---

# AI Engineering

Use this skill for AI/ML engineering tasks: model selection and integration, LLM application architecture, prompt and evaluation design, RAG pipelines, data processing, and monitoring of AI systems.

## Guidelines
- Validate model outputs and handle failure modes.
- Measure quality with reproducible evals.
- Protect user data and respect privacy.
- Prefer cost-effective models unless quality requires otherwise.
