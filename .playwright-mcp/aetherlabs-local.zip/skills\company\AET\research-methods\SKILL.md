---
slug: "research-methods"
metadata:
  paperclip:
    slug: "research-methods"
    skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/research-methods"
  paperclipSkillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/research-methods"
  skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/research-methods"
key: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/research-methods"
---

---
name: research-methods
description: Research methodology, literature review, analysis, and evidence synthesis.
---

# Research Methods

Use this skill for research tasks: problem framing, literature and market review, experimental design, data analysis, evidence synthesis, and clear research reporting with sources and uncertainty labels.

## Guidelines
- Separate verified facts from assumptions.
- Cite sources and dates.
- Prefer primary sources.
- State limitations and next validation steps.
