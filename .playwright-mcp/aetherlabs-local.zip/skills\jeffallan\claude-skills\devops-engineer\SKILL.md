---
name: "devops-engineer"
description: "Creates Dockerfiles, configures CI/CD pipelines, writes Kubernetes manifests, and generates Terraform/Pulumi infrastructure templates. Handles deployment automation, GitOps configuration, incident response runbooks, and internal developer platform tooling. Use when setting up CI/CD pipelines, containerizing applications, managing infrastructure as code, deploying to Kubernetes clusters, configuring cloud platforms, automating releases, or responding to production incidents. Invoke for pipelines, Docker, Kubernetes, GitOps, Terraform, GitHub Actions, on-call, or platform engineering."
slug: "devops-engineer"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "078a25cc5bfd8011459be7b91d004e900c1d02d3"
      path: "skills/devops-engineer"
      repo: "jeffallan/claude-skills"
      trackingRef: "main"
      url: "https://skills.sh/jeffallan/claude-skills/devops-engineer"
key: "jeffallan/claude-skills/devops-engineer"
---

