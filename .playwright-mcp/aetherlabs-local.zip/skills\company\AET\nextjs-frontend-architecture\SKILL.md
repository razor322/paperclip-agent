---
name: "nextjs-frontend-architecture"
description: "Mandatory company standards for Next.js App Router frontend development, folder structure, Server/Client components, Server Actions, testing, and AI agent execution."
slug: "nextjs-frontend-architecture"
metadata:
  paperclip:
    slug: "nextjs-frontend-architecture"
    skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/nextjs-frontend-architecture"
  paperclipSkillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/nextjs-frontend-architecture"
  skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/nextjs-frontend-architecture"
key: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/nextjs-frontend-architecture"
---

# Next.js Standardized Frontend Architecture

## 1. Architectural Foundation
- **Modular Domain Design:** All business domain capabilities live in `src/features/<domain>/`.
- **Reusable Primitives:** Shared components, layout chrome, and generic utilities live in `src/shared/`.
- **Composition Root:** Routes, metadata, session verification, and async data loading orchestration live in `src/app/`.
- **Cross-Feature Import Prohibition:** A feature module (`features/auth`) must never import directly from another feature module (`features/billing`). Cross-feature composition occurs in `src/app/**/page.tsx` or by elevating logic to `src/shared/`.

## 2. Server vs Client Component Boundaries
- **Default to Server:** Next.js App Router defaults to React Server Components (RSC).
- **Push `'use client'` to the Leaves:** Only mark leaf components that require interactivity (event listeners, `useState`, browser APIs) with `'use client'`. Never put `'use client'` on `page.tsx` or `layout.tsx`. Pass Server Components as `children` into Client Component containers.
- **Data Fetching:** Fetch server data with async/await in Server Components using native `fetch` caching and React cache.
- **Mutations:** Execute mutations using Server Actions (`"use server"`). Enforce Zod input validation at the trust boundary. Explicitly revalidate cache paths (`revalidatePath`).

## 3. Directory Layout
- `src/app/`: File-system routing, layouts, loading skeletons, error boundaries.
- `src/features/<domain>/`: Feature api, components, hooks, types, and utils.
- `src/shared/`: Design system UI primitives (`shared/components/ui/`), shell, lib clients, and utilities (`cn.ts`).

## 4. Coding & Clean Code Standards
- **Naming:** PascalCase for components, camelCase for hooks (`use*`), utilities, and actions.
- **Styling:** Tailwind CSS with `cn(...)` utility (`clsx` + `tailwind-merge`).
- **Dependencies:** Minimal external packages (YAGNI). Protect client bundles with `import "server-only"` on sensitive server utilities.

## 5. Testing & Verification
- **Unit & Integration:** Vitest + React Testing Library (accessible queries: `getByRole`).
- **End-to-End:** Playwright for critical paths.
- **Pre-Completion:** Always run `pnpm typecheck`, `pnpm lint`, and `pnpm test`.
