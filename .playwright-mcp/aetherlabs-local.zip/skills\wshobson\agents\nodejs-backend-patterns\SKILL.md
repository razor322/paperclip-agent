---
name: "nodejs-backend-patterns"
description: "Build production-ready Node.js backend services with Express/Fastify, implementing middleware patterns, error handling, authentication, database integration, and API design best practices. Use when creating Node.js servers, REST APIs, GraphQL backends, or microservices architectures."
slug: "nodejs-backend-patterns"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "7e2fb559cf4b824b27f1fec49fe88f7511066d26"
      path: "plugins/javascript-typescript/skills/nodejs-backend-patterns"
      repo: "wshobson/agents"
      trackingRef: "main"
      url: "https://skills.sh/wshobson/agents/nodejs-backend-patterns"
key: "wshobson/agents/nodejs-backend-patterns"
---

