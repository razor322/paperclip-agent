---
name: "security-review"
description: "Security code review for vulnerabilities. Use when asked to \"security review\", \"find vulnerabilities\", \"check for security issues\", \"audit security\", \"OWASP review\", or review code for injection, XSS, authentication, authorization, cryptography issues. Provides systematic review with confidence-based reporting."
slug: "security-review"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "0c464f411bdfb8d4c12314b36264d06cb2f60270"
      path: "skills/security-review"
      repo: "getsentry/skills"
      trackingRef: "main"
      url: "https://skills.sh/getsentry/skills/security-review"
key: "getsentry/skills/security-review"
---

