---
name: "frontend-design"
description: "Guidance for distinctive, intentional visual design when building new UI or reshaping an existing one. Helps with aesthetic direction, typography, and making choices that don't read as templated defaults."
slug: "frontend-design"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "ca45fc496a3436251f191354091d557da31c15b5"
      path: "skills/frontend-design"
      repo: "anthropics/skills"
      trackingRef: "main"
      url: "https://skills.sh/anthropics/skills/frontend-design"
key: "anthropics/skills/frontend-design"
---

