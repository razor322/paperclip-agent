---
slug: "blockchain-engineering"
metadata:
  paperclip:
    slug: "blockchain-engineering"
    skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/blockchain-engineering"
  paperclipSkillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/blockchain-engineering"
  skillKey: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/blockchain-engineering"
key: "company/ef31c11a-bc89-4c71-afce-48a4e9652065/blockchain-engineering"
---

---
name: blockchain-engineering
description: Blockchain development, smart contracts, Web3 integrations, and crypto system design.
---

# Blockchain Engineering

Use this skill for blockchain development tasks: smart contract design and implementation, Web3 integrations, wallet interactions, token mechanics, consensus considerations, and security review of on-chain code.

## Guidelines
- Prefer well-audited standards and established patterns.
- Treat private keys and secrets as sensitive; never expose them.
- Include tests for contract logic and edge cases.
- Document deployment and upgrade paths.
